=== WhatsApp Chat for WordPress ===
Contributors: jagdish1o1
Tags: whatsapp chat, chat plugin for wordpress, wordpress chat, whatsapp support chat
Donate link: https://iamjagdish.com
Requires at least: 4.9
Tested up to: 5.2
Requires PHP: 5.2.4
License: GPL2
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Simplifying WhatsApp Chat for WordPress.

== Description ==
WhatsApp is one of the most popular messaging app, and it's a great way to chat with your website's visitors or customers.

Giving support through WhatsApp can give you more conversion as you can answer/solve visitor's queries instantly.

= Shortcode =

[wac_shortcode]

Use shortcode to display WhatsApp Chat Badges.

== Installation ==
= Way 1: =
1. Upload plugin to the /wp-content/plugins/ directory
2. Extract the zip file.
3. Activate the plugin from wordpress plugins page. And you have done.

= Way 2: =
1. Go to plugins page in admin.
2. Click on Add New button.
3. Search for “WhatsApp Chat for WordPress”.
4. Click install on WhatsApp Chat for WordPress.
5. Activate the plugin

== Screenshots ==
1. Setting screen, add as much members you want.
2. Plugin in action.
3. Shortcode Preview [wac_shortcode].